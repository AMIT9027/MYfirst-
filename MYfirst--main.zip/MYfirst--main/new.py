a=10
b=20
sums=a+b
print(sums)
